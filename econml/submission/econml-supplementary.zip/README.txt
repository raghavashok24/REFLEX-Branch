Supplementary material
======================

Code for "Herd Immunity and Adaptive Learning Externalities under Shared
Foundational Models". Anonymized: no author names, no repository URL, no
absolute paths. The repository is linked in the camera-ready version.

Contents
--------

  ml-contributions/certificates/    eight assertion-based certificate files, 542 checks
  ml-contributions/experiments/     the six-panel harness and its committed result JSONs
  ml-contributions/theory/          the closed-form module the certificates check against
  ml-contributions/environment/     the heterogeneous-response reference environment
  paper/make_figures.py             regenerates every figure from the committed JSONs

Reproducing
-----------

Python 3.12, numpy, scipy (scipy is used only by verify_ensemble_intervals.py,
for the exact Clopper-Pearson interval), matplotlib for the figures.

    for f in ml-contributions/certificates/verify_*.py; do python "$f"; done
    python ml-contributions/experiments/run_panels.py
    python paper/make_figures.py

The full suite is CPU-only and runs in about twenty seconds on one commodity
laptop core. Every panel is deterministic from a (config, seed) pair.

Panel 1 is the paper's one measured result. It runs against the external
order-flow simulator of the cited preprint, which is prior work and is not
redistributed here; its measured outputs are committed under
ml-contributions/experiments/results/ and are reproduced by the rest of the
suite bit for bit.
